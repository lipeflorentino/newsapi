'use strict';

const express = require('express'),
app           = express(),
bodyParser    = require('body-parser'),
helmet 	      = require('helmet'),
cors          = require('cors'),
consign       = require('consign'),
conn          = require('./config/db_connection.js');

const port = process.env.PORT || 3000;
// conectando com a base de dados
conn.connect(function(err) {
    if (err) throw err;
    console.log('conectou!');
});

//informando ao app qual porta escutar
app.listen(port);
console.log('RESTful API - Webedia server started on: ' + port);

app.use(cors());
app.use(helmet());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

//importando as rotas da aplicação
const routes = require('./routes/newsRoutes'); 
//registrando a rota
routes(app); 

consign()
    .include('routes')
    .into(app);

module.exports = app;