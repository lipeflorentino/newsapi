'use strict';
module.exports = function(app) {
    const cont = require('../controllers/pets');

    console.log('cheguei na rota!');

    // os endpoints da aplicação
    app.route('/pets').get(cont.listarPets);
    
};