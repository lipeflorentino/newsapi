'use strict';

exports.listarPets = function (req, res) {
        res.status(200).send({message: 'listing pets'});
    };